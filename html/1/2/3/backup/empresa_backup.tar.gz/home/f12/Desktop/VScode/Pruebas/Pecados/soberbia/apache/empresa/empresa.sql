CREATE DATABASE mi_base_de_datos;
USE mi_empresa;

-- Crear tabla de usuarios
CREATE TABLE usuarios (
    id INT PRIMARY KEY,
    username VARCHAR(255),
    password VARCHAR(255),
    email VARCHAR(255)
);

-- Insertar datos de usuarios
INSERT INTO usuarios VALUES
(1, 'admin', 'admin123', 'admin@example.com'),
(2, 'user1', 'user1pass', 'user1@example.com'),
(3, 'guest', 'guestpass', 'guest@example.com');